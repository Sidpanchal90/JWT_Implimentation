package com.blogs.payloads;

public class ImageResponse {

}
