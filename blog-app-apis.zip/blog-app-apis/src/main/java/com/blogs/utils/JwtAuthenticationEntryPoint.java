
package com.blogs.utils;

/*
 * @Component public class JwtAuthenticationEntryPoint implements
 * AuthenticationEntryPoint {
 * 
 * @Override public void commence(HttpServletRequest request,
 * HttpServletResponse response,
 * org.springframework.security.core.AuthenticationException authException)
 * throws IOException, ServletException {
 * response.setStatus(HttpServletResponse.SC_UNAUTHORIZED); PrintWriter writer =
 * response.getWriter(); writer.println("Access Denied !! " +
 * authException.getMessage()); }
 * 
 * }
 */
