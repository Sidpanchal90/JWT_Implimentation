/*
 * package com.blogs;
 * 
 * import org.junit.jupiter.api.Test; import
 * org.springframework.beans.factory.annotation.Autowired; import
 * org.springframework.boot.test.context.SpringBootTest;
 * 
 * import com.blogs.dau.UserRepo;
 * 
 * @SpringBootTest class BlogAppApisApplicationTest {
 * 
 * @Autowired private UserRepo repo;
 * 
 * @Test void contextLoads() { }
 * 
 * @Test public void repoTest() {
 * 
 * String name = this.repo.getClass().getName(); String name2 =
 * this.repo.getClass().getPackageName();
 * 
 * System.out.println(name); System.out.println(name2);
 * 
 * }
 * 
 * }
 */